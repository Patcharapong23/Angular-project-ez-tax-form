import { Component } from '@angular/core';
import { LoadingService } from './shared/Loding/loading.service'; // ✅ แก้พาธ loading
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html', // ✅ ใช้ไฟล์ HTML แยก
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  loading$ = this.loading.isLoading$;
  constructor(private loading: LoadingService, private http: HttpClient) {}

  // ปุ่มทดสอบแบบ manual
  fakeWork() {
    this.loading.show();
    setTimeout(() => this.loading.hide(), 2000);
  }

  // ปุ่มทดสอบผ่าน HTTP (ให้ Interceptor โชว์เอง)
  testHttp() {
    this.http
      .get('/api/ping', { responseType: 'text' })
      .subscribe({ next: () => {}, error: () => {} });
  }
}
