export interface UploadLogoResponse {
  url: string; // URL of the uploaded logo
}
