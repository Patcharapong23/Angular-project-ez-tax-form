export const environment = {
  production: true,
  apiBase: 'http://localhost:8080/api',
};
