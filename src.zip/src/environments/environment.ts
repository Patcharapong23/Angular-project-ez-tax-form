// export const environment = {
//   production: false,
//   apiBase: 'http://localhost:8080/api',
//   // useMock: false,
//   // tokenStorageKey: 'auth.token',
//   // userStorageKey: 'auth.user',
// };
export const environment = {
  production: false,
  apiBase: '/api',
};
