declare module 'tic-tac-toe-minimax';
