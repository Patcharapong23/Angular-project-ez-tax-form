import { Injectable } from '@angular/core';
import { CanActivate, Router, UrlTree } from '@angular/router';
import { AuthService } from './shared/auth.service';

@Injectable({ providedIn: 'root' })
export class GuestGuard implements CanActivate {
  constructor(private auth: AuthService, private router: Router) {}

  canActivate(): boolean | UrlTree {
    // ถ้าล็อกอินแล้ว ไม่ให้เข้า /login /register → ส่งไป dashboard
    return this.auth.isLoggedIn()
      ? this.router.createUrlTree(['/dashboard'])
      : true;
  }
}
