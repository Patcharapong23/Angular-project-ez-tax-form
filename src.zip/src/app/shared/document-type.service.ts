import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

// ตรงนี้ให้ตรงกับ DocumentTypeResponse ของ backend
export interface DocumentTypeOption {
  code: string;
  labelTh: string;
  labelEn: string;
  sort: number;
}

@Injectable({ providedIn: 'root' })
export class DocumentTypeService {
  private baseUrl = 'http://localhost:8080/api/document-types';

  constructor(private http: HttpClient) {}

  list(): Observable<DocumentTypeOption[]> {
    return this.http.get<DocumentTypeOption[]>(this.baseUrl);
  }
}
