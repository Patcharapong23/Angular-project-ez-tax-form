// src/app/shared/services/org.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, forkJoin, of } from 'rxjs';
import { map, switchMap, catchError } from 'rxjs/operators';
import { environment } from '../../../environments/environment';

export interface SellerProfile {
  companyName: string;
  taxId: string;
  branchCode: string;
  branchName: string;
  tel?: string;
  address: string;
  logoUrl?: string;
  branches: { code: string; name: string }[];
}

@Injectable({ providedIn: 'root' })
export class OrgService {
  private api = environment.apiBase; // ใช้ตัวเดียวกับ DocumentService

  constructor(private http: HttpClient) {}
  me(): Observable<SellerProfile> {
    return this.http.get<SellerProfile>(`${this.api}/auth/me`).pipe(
      catchError(() =>
        of({
          companyName: '',
          taxId: '',
          branchCode: '00000',
          branchName: 'สำนักงานใหญ่',
          tel: '',
          address: '',
          logoUrl: '',
          branches: [{ code: '00000', name: 'สำนักงานใหญ่' }],
        } as SellerProfile)
      )
    );
  }
  /** โหลดข้อมูลผู้ขายของผู้ใช้ปัจจุบัน + รายการสาขา */
  loadSellerProfile(): Observable<SellerProfile> {
    return this.http.get<any>(`${this.api}/auth/me`).pipe(
      switchMap((me: any) => {
        const branchId = me?.branchId;
        const tenantId = me?.tenantId;

        const branch$ = branchId
          ? this.http.get<any>(`${this.api}/branches/${branchId}`)
          : of(null);

        const tenant$ = tenantId
          ? this.http.get<any>(`${this.api}/tenants/${tenantId}`)
          : of(null);

        const branches$ = tenantId
          ? this.http.get<any[]>(`${this.api}/branches?tenantId=${tenantId}`)
          : of([{ branchCode: '00000', nameTh: 'สำนักงานใหญ่' }]);

        return forkJoin([of(me), branch$, tenant$, branches$]);
      }),
      map(([me, branch, tenant, branches]) => {
        const profile: SellerProfile = {
          companyName: tenant?.nameTh || tenant?.nameEn || '',
          taxId: tenant?.tenantTaxId || '',
          branchCode: branch?.branchCode || branch?.code || '00000',
          branchName:
            branch?.nameTh || branch?.nameEn || branch?.name || 'สำนักงานใหญ่',
          tel: tenant?.tel || '',
          address:
            tenant?.addressDetailTh ||
            tenant?.addressDetailEn ||
            `${tenant?.buildingNo || ''} ${tenant?.district || ''} ${
              tenant?.province || ''
            } ${tenant?.zipCode || ''}`.trim(),
          logoUrl: tenant?.logoUrl || '',
          branches: (branches || []).map((b: any) => ({
            code: b.branchCode || b.code || b.id || '00000',
            name: b.nameTh || b.nameEn || b.name || b.branchCode || 'สาขา',
          })),
        };
        return profile;
      })
    );
  }
}
