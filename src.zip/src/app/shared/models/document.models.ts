// รายการในตารางหน้า “เอกสารทั้งหมด”
export interface DocumentListItem {
  id: number;
  docNo: string;
  docTypeCode: string;
  issueDate: string;
  sellerName: string;
  customerName: string;
  grandTotal: number;
  customerTaxId?: string;
  branchCode?: string;
  createdAt?: string;
  status?: 'DRAFT' | 'CONFIRMED' | 'CANCELLED';
}

// payload สำหรับสร้างเอกสาร
export interface DocumentCreatePayload {
  docTypeCode: string;
  docNo?: string;
  issueDate: string;
  sellerName: string;
  sellerTaxId?: string;
  sellerBranchCode?: string;
  sellerBranchName?: string;
  sellerTel?: string;
  sellerAddress?: string;
  customerType?: string;
  customerCode?: string;
  customerName?: string;
  customerTaxId?: string;
  customerPassportNo?: string;
  customerBranchCode?: string;
  customerAddress?: string;
  customerEmail?: string;
  customerTel?: string;
  customerZip?: string;
  subtotal: number;
  discountTotal: number;
  netAfterDiscount: number;
  serviceFee?: number;
  shippingFee?: number;
  vatAmount: number;
  grandTotal: number;
  remark?: string;
}

// รายละเอียดเต็ม (ใช้ patch ฟอร์มตอนแก้ไข)
export interface EzDocumentFull {
  id: number;
  docNo: string;
  docTypeCode: string | null;
  issueDate: string;

  sellerName?: string;
  sellerTaxId?: string;
  sellerBranchCode?: string;
  sellerBranchName?: string;
  sellerAddress?: string;
  sellerTel?: string;

  customerType?: string;
  customerCode?: string;
  customerName?: string;
  customerTaxId?: string;
  customerPassportNo?: string;
  customerBranchCode?: string;
  customerAddress?: string;
  customerEmail?: string;
  customerTel?: string;
  customerZip?: string;

  subtotal?: number;
  discountTotal?: number;
  netAfterDiscount?: number;
  serviceFee?: number;
  shippingFee?: number;
  vatAmount?: number;
  grandTotal?: number;

  remark?: string;
  status?: 'DRAFT' | 'CONFIRMED' | 'CANCELLED';
  createdAt?: string;
}
