// src/app/shared/master-data.service.ts
import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// import { environment } from '../../environments/environment';
// import { Observable } from 'rxjs';

// export interface DocTypeDto {
//   code: string;
//   label: string;
// }

// @Injectable({ providedIn: 'root' })
// export class MasterDataService {
//   private base = environment.apiBase; // เช่น http://localhost:8080/api
//   constructor(private http: HttpClient) {}

//   getDocumentTypes(): Observable<DocTypeDto[]> {
//     return this.http.get<DocTypeDto[]>(`${this.base}/document-types`);
//   }
// }
