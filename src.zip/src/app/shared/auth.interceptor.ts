import { Injectable } from '@angular/core';
import {
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { AuthService } from './auth.service';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  constructor(private auth: AuthService) {}

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    const apiBase = environment.apiBase; // '/api'
    const isApi =
      req.url.startsWith(apiBase) || req.url.includes('://localhost:8080/');
    const isAuthEndpoint =
      req.url.endsWith('/auth/login') || req.url.endsWith('/auth/register');

    if (isApi && !isAuthEndpoint) {
      const token = this.auth.token;
      if (token) {
        req = req.clone({
          setHeaders: { Authorization: `Bearer ${token}` },
        });
      }
    }
    return next.handle(req);
  }
}
