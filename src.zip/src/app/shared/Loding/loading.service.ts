// src/app/shared/Loding/loading.service.ts
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { distinctUntilChanged, delay } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class LoadingService {
  // ตัว subject ภายใน
  private _loading$ = new BehaviorSubject<boolean>(false);

  // ตัว observable ที่ component ใช้
  // ใส่ delay(0) เพื่อเลื่อนการ emit ค่าใหม่ไป tick ถัดไป
  // distinctUntilChanged() กัน emit ค่าเดิมซ้ำ
  isLoading$: Observable<boolean> = this._loading$.pipe(
    distinctUntilChanged(),
    delay(0)
  );

  show(): void {
    // ถ้าอยากให้ safe แบบ 100% สำหรับรอบแรกมากๆ
    // สามารถใช้ setTimeout(() => this._loading$.next(true), 0)
    // แต่ส่วนใหญ่ next ตรงได้เพราะเราหน่วงตอนอ่านด้วย delay()
    this._loading$.next(true);
  }

  hide(): void {
    this._loading$.next(false);
  }
}
