// src/app/shared/auth.service.ts
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';

export type Role = 'HQ_ADMIN' | 'BRANCH_ADMIN' | 'STAFF' | 'SYSTEM_ADMIN';

export interface AuthResponse {
  token: string;
  refreshToken?: string | null;
  userName: string;
  fullName: string;
  email: string;
  role: Role;
}

export interface BranchLite {
  id: number;
  code: string;
  nameTh: string;
  tel?: string | null;
  addressLine?: string | null;
}

export type AddressTh = {
  buildingNo?: string;
  addressDetailTh?: string;
  province?: string; // code
  district?: string; // code
  subdistrict?: string; // code
  zipCode?: string; // 5 digits
};

export interface AuthUser {
  userName: string;
  fullName: string;
  email: string;
  role?: string;

  tenantId?: number;
  tenantNameTh?: string;
  tenantNameEn?: string;
  tenantTaxId?: string;
  logoUrl?: string | null;
  tenantTel?: string | null;
  addressLine?: string | null;
  addressTh?: AddressTh;

  branchId?: number | null;
  branchCode?: string;
  branchNameTh?: string;

  branches?: BranchLite[];

  companyName?: string; // legacy
}

export interface RegisterDto {
  password: string;
  fullName: string;
  email: string;

  // โลโก้ (optional)
  logoImg?: string | null;
  logoUrl?: string;

  // บริษัท/ผู้ขาย
  tenantNameTh: string;
  tenantNameEn?: string;
  tenantTaxId: string;

  // สาขา
  branchCode: string;
  branchNameTh: string;
  branchNameEn?: string;

  tenantTel?: string;

  // ที่อยู่ไทย
  buildingNo: string;
  addressDetailTh?: string; // <= 255
  province: string; // code
  district: string; // code
  subdistrict: string; // code
  zipCode: string; // 5 digits

  // อังกฤษ (optional)
  addressDetailEn?: string;
}

const TOKEN_KEY = 'auth.token';
const USER_KEY = 'auth.user';
const LOGOUT_BC = 'logout.broadcast';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private base = environment.apiBase; // เช่น '/api' หรือ 'http://localhost:8080/api'

  private _user$ = new BehaviorSubject<AuthUser | null>(readUserFromStorage());
  private _loggedIn$ = new BehaviorSubject<boolean>(!!readToken());

  readonly user$ = this._user$.asObservable();
  readonly loggedIn$ = this._loggedIn$.asObservable();

  constructor(private http: HttpClient, private router: Router) {
    // sync logout จากแท็บอื่น
    window.addEventListener('storage', (e) => {
      if (e.key === TOKEN_KEY && e.newValue === null) {
        this.clearUser();
        this.router.navigateByUrl('/login');
      }
    });
  }

  // ---------- token ----------
  get token(): string | null {
    return readToken();
  }

  // ใช้จาก service อื่น (เช่น DocumentTypeService)
  getToken(): string | null {
    return readToken();
  }

  private setToken(t: string) {
    localStorage.setItem(TOKEN_KEY, t);
    this._loggedIn$.next(true);
  }

  private clearToken() {
    localStorage.removeItem(TOKEN_KEY);
    this._loggedIn$.next(false);
  }

  private authHeaders(): HttpHeaders {
    const t = this.token;
    return t
      ? new HttpHeaders({ Authorization: `Bearer ${t}` })
      : new HttpHeaders();
  }

  // ---------- user ----------
  getUser(): AuthUser | null {
    return this._user$.value ?? readUserFromStorage();
  }

  private setUser(u: AuthUser) {
    localStorage.setItem(USER_KEY, JSON.stringify(u));
    this._user$.next(u);
  }

  private clearUser() {
    localStorage.removeItem(USER_KEY);
    this._user$.next(null);
  }

  // ---------- call backend logout ----------
  serverLogout() {
    return this.http.post<void>(
      `${this.base}/auth/logout`,
      {},
      { headers: this.authHeaders() }
    );
  }

  // ---------- jwt ----------
  decodeToken(): any {
    const t = this.token;
    if (!t) return null;
    const parts = t.split('.');
    if (parts.length < 2) return null;
    try {
      const base64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
      return JSON.parse(atob(base64));
    } catch {
      return null;
    }
  }

  isLoggedIn(): boolean {
    const t = this.token;
    if (!t) return false;
    const payload = this.decodeToken();
    if (!payload?.exp) return false;
    return Math.floor(Date.now() / 1000) < payload.exp;
  }

  logout(broadcast = true): void {
    this.clearToken();
    this.clearUser();
    if (broadcast) localStorage.setItem(LOGOUT_BC, String(Date.now()));
    this.router.navigateByUrl('/login');
  }

  // ---------- /auth/me ----------
  fetchMe() {
    return this.http
      .get<AuthUser>(`${this.base}/auth/me`, { headers: this.authHeaders() })
      .pipe(
        tap((m) => {
          // map response -> AuthUser ที่ frontend ใช้จริง
          const u: AuthUser = {
            userName: (m as any).userName ?? (m as any).username ?? '',
            fullName: m.fullName,
            email: m.email,
            role: (m as any).role,

            tenantId: (m as any).tenantId,
            tenantNameTh: (m as any).tenantNameTh,
            tenantNameEn: (m as any).tenantNameEn,
            tenantTaxId: (m as any).tenantTaxId,
            logoUrl: (m as any).logoUrl ?? null,
            tenantTel: (m as any).tenantTel ?? null,
            addressLine: (m as any).addressLine ?? null,

            branchId: (m as any).branchId ?? null,
            branchCode: (m as any).branchCode,
            branchNameTh: (m as any).branchNameTh,

            branches: Array.isArray((m as any).branches)
              ? (m as any).branches.map((b: any) => ({
                  id: b.id,
                  code: b.code,
                  nameTh: b.nameTh,
                  tel: b.tel ?? null,
                  addressLine: b.addressLine ?? null,
                }))
              : [],
          };

          // แปะ addressTh ถ้าหลังบ้านส่งมา
          if ((m as any).addressTh) {
            u.addressTh = (m as any).addressTh as AddressTh;
          }

          this.setUser(u);
        })
      );
  }

  // ---------- upload logo ----------
  uploadLogo(file: File, tenantTaxId: string) {
    const form = new FormData();
    form.append('file', file);
    form.append('tenantTaxId', tenantTaxId);
    return this.http.post<{ url: string }>(`${this.base}/files/logo`, form, {
      headers: this.authHeaders(),
    });
  }

  // ---------- login ----------
  login(userName: string, password: string): Observable<AuthResponse> {
    const body = { userName, password };
    return this.http
      .post<AuthResponse>(`${this.base}/auth/login`, body, {
        headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
      })
      .pipe(
        tap((res) => {
          this.setToken(res.token);

          const claims = this.decodeToken();
          const role =
            res.role ??
            claims?.role ??
            claims?.roles?.[0] ??
            claims?.authorities?.[0] ??
            undefined;

          const u: AuthUser = {
            userName: res.userName,
            fullName: res.fullName,
            email: res.email,
            role,
          };
          this.setUser(u);
        })
      );
  }

  // ---------- register ----------
  /**
   * รับ payload ได้หลายรูปแบบ (ยืดหยุ่นกับฟอร์ม):
   * - form payload ที่ component ส่งมา (มี addressTh.{...})
   * - RegisterDto แบบตรง ๆ
   * - คีย์ที่เป็นอ็อบเจ็กต์ {code,name_th} จะถูกแปลงเป็น code ให้เอง
   */
  register(payload: any) {
    const codeOf = (v: any): string => {
      if (!v) return '';
      if (typeof v === 'object' && 'code' in v) return String(v.code);
      return String(v);
    };

    // รองรับทั้งชื่อ userName/username, และ derive จาก email ได้
    const userName = (
      payload.username ??
      payload.userName ??
      (typeof payload.email === 'string'
        ? String(payload.email).split('@')[0]
        : '')
    )
      .toString()
      .trim();

    // รองรับ firstName/ fullName → ส่งทั้งสองคีย์ (กัน DTO เก่า/ใหม่)
    const name = (payload.fullName ?? '').toString().trim();

    // ดึงฟิลด์ที่อยู่ไทย (รองรับทั้งแบบราบ และซ้อนใน addressTh)
    const buildingNo = (
      payload.buildingNo ??
      payload.addressTh?.buildingNo ??
      ''
    )
      .toString()
      .trim();

    let addressDetailTh = (
      payload.addressDetailTh ??
      payload.addressTh?.addressDetailTh ??
      ''
    )
      .toString()
      .trim();

    if (addressDetailTh.length > 255) {
      addressDetailTh = addressDetailTh.slice(0, 255);
    }

    const provinceId = codeOf(
      payload.provinceId ?? payload.province ?? payload.addressTh?.province
    );
    const districtId = codeOf(
      payload.districtId ?? payload.district ?? payload.addressTh?.district
    );
    const subdistrictId = codeOf(
      payload.subdistrictId ??
        payload.subdistrict ??
        payload.addressTh?.subdistrict
    );
    const zipCode = (payload.zipCode ?? payload.addressTh?.zipCode ?? '')
      .toString()
      .padStart(5, '0');

    // company/tenant
    const sellerNameTh = (payload.sellerNameTh ?? payload.tenantNameTh ?? '')
      .toString()
      .trim();

    const body: any = {
      // user
      email: payload.email?.toString().trim(),
      userName,
      password: payload.password,
      fullName: name,
      logoImg: payload.logoImg ?? null,
      logoUrl: payload.logoUrl,
      tenantNameEn: payload.tenantNameEn,
      tenantTaxId: payload.tenantTaxId,
      tenantTel: payload.tenantTel,
      branchCode: payload.branchCode,
      branchNameTh: payload.branchNameTh,
      branchNameEn: payload.branchNameEn,
      addressDetailEn: payload.addressDetailEn,
      addressDetailTh: addressDetailTh,
    };

    // ส่งไปที่ backend
    return this.http.post(`${this.base}/eztax/register`, body, {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
    });
  }
}

// ---------- local helpers ----------
function readUserFromStorage(): AuthUser | null {
  try {
    const raw = localStorage.getItem(USER_KEY);
    return raw ? (JSON.parse(raw) as AuthUser) : null;
  } catch {
    return null;
  }
}

function readToken(): string | null {
  return localStorage.getItem(TOKEN_KEY) ?? null;
}
