// src/app/features/invoice/invoice.service.ts
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map, switchMap, catchError, of } from 'rxjs';
import { environment } from '../../../environments/environment';

/** รูปแบบที่คอมโพเนนต์ใช้อยู่จริง */
export interface Invoice {
  _id: string; // เดิมเป็น string | number
  documentNumber: string;
  customer: { taxId: string; name: string; branchCode?: string };
  documentType: string;
  issueDate: string;
  createdAt: string;
  status: 'DRAFT' | 'CONFIRMED' | 'CANCELLED';
  items: any[]; // เดิมเป็น items?: any[] (ดูข้อ 2 ด้านล่าง)
}

@Injectable({ providedIn: 'root' })
export class InvoiceService {
  private base = environment.apiBase; // เช่น http://localhost:8080/api

  constructor(private http: HttpClient) {}

  /** ===== LIST ===== */
  getInvoices(): Observable<Invoice[]> {
    const params = new HttpParams().set('type', 'IV');
    // คาดหวังให้หลังบ้านมี GET /api/document?type=IV
    return this.http
      .get<any[]>(`${this.base}/document`, { params })
      .pipe(map((list) => list?.map(this.mapHeaderToInvoice) ?? []));
  }

  /** ===== READ ONE ===== */
  getInvoice(id: number | string): Observable<Invoice> {
    return this.http
      .get<any>(`${this.base}/document/${id}`)
      .pipe(map(this.mapHeaderToInvoice));
  }

  /** ===== CREATE =====
   * ถ้ามี lock เบอร์เอกสารให้เรียก /doc-number/lock ก่อน แล้วค่อย submit
   */
  createInvoice(formData: any): Observable<Invoice> {
    const type = formData.docType ?? formData.documentType ?? 'IV';
    const branch =
      formData.branchCode ??
      formData.branch_id ??
      formData.branchId ??
      formData.branch;
    const dateISO = formData.docDate ?? formData.issueDate;

    if (branch && dateISO) {
      return this.http
        .post<any>(`${this.base}/doc-number/lock`, {
          type,
          branch,
          date: dateISO,
        })
        .pipe(
          switchMap((lock) =>
            this.http.post<any>(`${this.base}/document/submit`, {
              header: {
                ...formData,
                docNo: lock?.docNo ?? formData.documentNumber,
              },
              lockId: lock?.lockId,
            })
          ),
          map(this.mapHeaderToInvoice)
        );
    }

    // fallback ถ้ายังไม่มีข้อมูล branch/date ครบ
    return this.http
      .post<any>(`${this.base}/document/submit`, { header: formData })
      .pipe(map(this.mapHeaderToInvoice));
  }

  /** ===== UPDATE ===== */
  updateInvoice(id: number | string, formData: any): Observable<Invoice> {
    return this.http.put<any>(`${this.base}/document/${id}`, formData).pipe(
      map(this.mapHeaderToInvoice),
      // fallback ชั่วคราว ถ้ายังไม่มี PUT หลังบ้าน
      catchError(() =>
        this.http
          .post<any>(`${this.base}/document/submit`, {
            header: { ...formData, id },
          })
          .pipe(map(this.mapHeaderToInvoice))
      )
    );
  }

  /** ===== CANCEL ===== */
  cancelInvoice(id: number | string): Observable<void> {
    return this.http.post<void>(`${this.base}/document/${id}/cancel`, {}).pipe(
      // fallback เงียบ ๆ ระหว่าง dev ถ้ายังไม่มี endpoint
      catchError(() => of(void 0))
    );
  }

  /** ===== mapper: backend → Invoice (รุ่นที่คอมโพเนนต์ต้องการ) ===== */
  private mapHeaderToInvoice = (h: any): Invoice => {
    const id =
      h?.id ?? h?._id ?? h?.headerId ?? h?.documentId ?? h?.docId ?? '';
    const docNo = h?.docNo ?? h?.documentNumber ?? h?.doc_no ?? '';
    const docDate =
      h?.docDate ?? h?.issueDate ?? h?.doc_date ?? new Date().toISOString();
    const createdAt = h?.createdAt ?? h?.created_at ?? new Date().toISOString();
    const status = (h?.status ?? 'DRAFT') as
      | 'DRAFT'
      | 'CONFIRMED'
      | 'CANCELLED';

    const customer = h?.customer ?? {
      taxId: h?.customerTaxId ?? h?.taxId ?? '',
      name: h?.customerName ?? h?.name ?? '',
      branchCode: h?.branchCode ?? h?.branch_code ?? '',
    };

    return {
      _id: id || docNo || Date.now().toString(),
      documentNumber: docNo || '-',
      customer,
      documentType: h?.docType ?? h?.documentType ?? 'IV',
      issueDate: toDateOnly(docDate),
      createdAt: toIso(createdAt),
      status,
      items: h?.items ?? [],
    };
  };
}

/** ===== helpers ===== */
function toDateOnly(v: any): string {
  try {
    return new Date(v).toISOString().substring(0, 10);
  } catch {
    return new Date().toISOString().substring(0, 10);
  }
}
function toIso(v: any): string {
  try {
    return new Date(v).toISOString();
  } catch {
    return new Date().toISOString();
  }
}
