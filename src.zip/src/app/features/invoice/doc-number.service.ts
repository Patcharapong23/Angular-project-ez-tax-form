import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';

export type DocPreviewDto = { nextDocNo: string; locked?: boolean };
export type DocLockDto = { docNo: string; lockId: string };

@Injectable({ providedIn: 'root' })
export class DocNumberService {
  private base = `${environment.apiBase}/doc-number`;
  constructor(private http: HttpClient) {}

  preview(type: string, branch: string, dateISO: string) {
    const params = new HttpParams()
      .set('type', type)
      .set('branch', branch)
      .set('date', dateISO);
    return this.http.get<DocPreviewDto>(`${this.base}/preview`, { params });
  }
  lock(type: string, branch: string, dateISO: string) {
    return this.http.post<DocLockDto>(`${this.base}/lock`, {
      type,
      branch,
      date: dateISO,
    });
  }
}
