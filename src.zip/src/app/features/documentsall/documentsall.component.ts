import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { DocumentService } from '../documents/document.service';
import { DocumentListItem } from '../../shared/models/document.models';
import { NewDocumentDialogComponent } from '../dialogs/new-document-dialog/new-document-dialog.component';

export interface DocumentRow {
  id?: string; // keep optional เผื่อ template เก่า
  docNo: string;
  taxId: string;
  customer: string;
  branch: string;
  type: string;
  issueDate: string;
  createdAt: string;
  status: 'DRAFT' | 'CONFIRMED' | 'CANCELLED';
}

@Component({
  selector: 'app-documentsall',
  templateUrl: './documentsall.component.html',
  styleUrls: ['./documentsall.component.css'],
})
export class DocumentsallComponent implements OnInit {
  f: any = {};
  private all: DocumentListItem[] = [];
  rows: DocumentRow[] = [];

  constructor(
    private docs: DocumentService,
    private router: Router,
    public dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.docs.list().subscribe((items) => {
      this.all = items;
      this.search();
    });
  }

  private toStatus(s?: DocumentListItem['status']): DocumentRow['status'] {
    return s ?? 'DRAFT';
  }

  private toRows(items: DocumentListItem[]): DocumentRow[] {
    return items.map((d) => ({
      id: (d as any).id ? String((d as any).id) : d.docNo, // เผื่อ template เก่า
      docNo: d.docNo,
      taxId: d.customerTaxId ?? '-',
      customer: d.customerName ?? '-',
      branch: d.branchCode ?? 'สำนักงานใหญ่',
      type: d.docTypeCode,
      issueDate: d.issueDate,
      createdAt: d.createdAt ?? '',
      status: this.toStatus(d.status),
    }));
  }

  search(): void {
    const q = {
      docNo: this.f.docNo?.trim() || undefined,
      customerTaxId: this.f.customerTaxId?.trim() || undefined,
      docType: this.f.docType || undefined,
    };
    this.docs.list(q).subscribe((items) => (this.rows = this.toRows(items)));
  }

  clear(): void {
    this.f = {};
    this.search();
  }

  getStatusClass(s: string): string {
    if (s === 'CONFIRMED') return 'badge-green';
    if (s === 'CANCELLED') return 'badge-red';
    return 'badge-gray';
  }
  getStatusText(s: string): string {
    if (s === 'CONFIRMED') return 'ใช้งาน';
    if (s === 'CANCELLED') return 'ยกเลิก';
    return 'ฉบับร่าง';
  }

  // ✅ ใช้ docNo เป็น key หลัก
  viewInvoice(docNo: string): void {
    this.router.navigate(['/invoice/edit', docNo]);
  }
  editInvoice(docNo: string): void {
    this.router.navigate(['/invoice/edit', docNo]);
  }
  cancelInvoice(docNo: string): void {
    if (!confirm('ยืนยันยกเลิกเอกสารนี้?')) return;
    // รอ endpoint cancelByDocNo ในอนาคต
  }

  createNewDocument(): void {
    const dialogRef = this.dialog.open(NewDocumentDialogComponent, {
      width: '900px',
      maxWidth: '95vw',
      panelClass: 'newdoc-dialog',
      backdropClass: 'newdoc-backdrop',
      autoFocus: false,
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (!result) return;
      this.router.navigate(['/invoice-form'], {
        state: {
          docTypeCode: result.docTypeCode,
          docTypeTh: result.docTypeTh,
          docTypeEn: result.docTypeEn,
          templateCode: result.templateCode,
          templateName: result.templateName,
        },
      });
    });
  }
}
