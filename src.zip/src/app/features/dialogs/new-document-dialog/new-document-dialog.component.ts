import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import {
  DocumentTypeService,
  DocumentTypeOption,
} from '../../../shared/document-type.service';

// template เลือกได้ เช่น BASIC, ALT1 อะไรแบบนี้
interface TemplateOption {
  code: string;
  viewValue: string;
  allowFor: string[]; // list ของ docTypeCode ที่ใช้ template นี้ได้
}

@Component({
  selector: 'app-new-document-dialog',
  templateUrl: './new-document-dialog.component.html',
  styleUrls: ['./new-document-dialog.component.css'],
})
export class NewDocumentDialogComponent implements OnInit {
  // dropdown state
  opened = {
    type: false,
    template: false,
  };

  // จาก backend
  docTypes: DocumentTypeOption[] = [];

  // templates ด้านขวา (mock ไว้ก่อน)
  allTemplates: TemplateOption[] = [
    {
      code: 'BASIC',
      viewValue: 'ฟอร์มมาตรฐาน',
      allowFor: ['T01', 'T02', 'T03', 'T04'], // code ของเอกสารที่อนุญาต
    },
    {
      code: 'ALT1',
      viewValue: 'แบบฟอร์มแนวนอน / มีช่องลายเซ็น',
      allowFor: ['T03', 'T04'],
    },
  ];

  filteredTemplates: TemplateOption[] = [];

  // ตัวที่ผู้ใช้เลือก
  selectedDocType: DocumentTypeOption | null = null;
  selectedTemplate: TemplateOption | null = null;

  constructor(
    private dialogRef: MatDialogRef<NewDocumentDialogComponent>,
    private router: Router,
    private docTypeSvc: DocumentTypeService
  ) {}

  ngOnInit(): void {
    // โหลดประเภทเอกสารจาก backend
    this.docTypeSvc.list().subscribe({
      next: (types) => {
        this.docTypes = types;
      },
      error: (err) => {
        console.error('[Dialog] โหลด document types ไม่ได้:', err);
        this.docTypes = [];
      },
    });
  }

  // เปิด/ปิด dropdown
  toggleDropdown(which: 'type' | 'template'): void {
    this.opened[which] = !this.opened[which];
  }

  // เมื่อเลือกประเภทเอกสาร
  selectDocType(doc: DocumentTypeOption): void {
    this.selectedDocType = doc;
    this.opened.type = false;

    // รีคอมโบ template ให้เหลือเฉพาะที่ใช้กับ doc นี้ได้
    this.filteredTemplates = this.allTemplates.filter((tpl) =>
      tpl.allowFor.includes(doc.code)
    );

    // auto-เลือก template ถ้ามีอันเดียว
    if (this.filteredTemplates.length === 1) {
      this.selectedTemplate = this.filteredTemplates[0];
    } else {
      this.selectedTemplate = null;
    }
  }

  // เลือก template
  selectTemplate(tpl: TemplateOption): void {
    this.selectedTemplate = tpl;
    this.opened.template = false;
  }

  // กดปุ่มกากบาท
  close(): void {
    this.dialogRef.close();
  }

  // >>> อันนี้คือปุ่ม "ดำเนินการต่อ"
  submit(): void {
    if (!this.selectedDocType) return;

    this.dialogRef.close();
    this.router.navigate(['/invoice-form'], {
      queryParams: {
        // ส่งให้ครบ 3 ตัว
        docTypeCode: this.selectedDocType.code,
        docTypeTh: this.selectedDocType.labelTh,
        docTypeEn: this.selectedDocType.labelEn,
        template: this.selectedTemplate?.viewValue || null,
      },
    });
  }
}
