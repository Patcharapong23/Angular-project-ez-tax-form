import { Component, OnInit } from '@angular/core';
import { DocumentService } from './document.service';
import { DocumentListItem } from '../../shared/models/document.models';

@Component({
  selector: 'app-list-documents',
  templateUrl: './list-documents.component.html',
})
export class ListDocumentsComponent implements OnInit {
  rows: DocumentListItem[] = [];
  loading = true;

  constructor(private api: DocumentService) {}

  ngOnInit() {
    this.api.list().subscribe({
      next: (r) => {
        this.rows = r;
        this.loading = false;
      },
      error: (_) => {
        this.loading = false;
      },
    });
  }
}
