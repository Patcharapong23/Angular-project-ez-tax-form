import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  DocumentListItem,
  DocumentCreatePayload,
  EzDocumentFull,
} from '../../shared/models/document.models';

@Injectable({ providedIn: 'root' })
export class DocumentService {
  private readonly base = `${environment.apiBase}/documents`;
  constructor(private http: HttpClient) {}

  list(q?: {
    docNo?: string;
    customerTaxId?: string;
    docType?: string;
  }): Observable<DocumentListItem[]> {
    let params = new HttpParams();
    if (q?.docNo) params = params.set('docNo', q.docNo);
    if (q?.customerTaxId) params = params.set('customerTaxId', q.customerTaxId);
    if (q?.docType) params = params.set('docType', q.docType);
    return this.http.get<DocumentListItem[]>(this.base, { params });
  }

  create(body: DocumentCreatePayload): Observable<EzDocumentFull> {
    return this.http.post<EzDocumentFull>(this.base, body);
  }

  get(id: number): Observable<EzDocumentFull> {
    return this.http.get<EzDocumentFull>(`${this.base}/${id}`);
  }

  // ✅ ใหม่: ดึงด้วยเลขที่เอกสาร
  getByDocNo(docNo: string): Observable<EzDocumentFull> {
    return this.http.get<EzDocumentFull>(
      `${this.base}/by-no/${encodeURIComponent(docNo)}`
    );
  }
  getByDocNoDetail(docNo: string) {
    // ตัวอย่าง: API ที่คืนรายละเอียดเต็มของเอกสารจากเลขที่เอกสาร
    return this.http.get<any>(
      `${this.base}/by-no/${encodeURIComponent(docNo)}`
    );
  }

  cancel(id: number): Observable<void> {
    return this.http.delete<void>(`${this.base}/${id}`);
  }

  // ดาวน์โหลดไฟล์ (ยังเป็น stub PDF/XML/CSV จากหลังบ้าน)
  downloadDocumentFile(
    id: number,
    format: 'PDF' | 'XML' | 'CSV'
  ): Observable<Blob> {
    const url = `${this.base}/${id}/export`;
    const params = new HttpParams().set('fmt', format.toLowerCase());
    const accept =
      format === 'PDF'
        ? 'application/pdf'
        : format === 'XML'
        ? 'application/xml'
        : 'text/csv';
    return this.http.get(url, {
      params,
      responseType: 'blob',
      headers: { Accept: accept },
    });
  }
}
