import { Component, HostListener, OnInit } from '@angular/core';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.css'],
})
export class LayoutComponent implements OnInit {
  // [ADDED] sidebar สถานะฝั่ง desktop
  isCollapsed = true; // true = แคบ 80px, false = กว้าง 260px

  // [ADDED] responsive flags
  isMobileView = false; // true เมื่อหน้าจอ < 1024px
  mobileSidebarOpen = false; // true = drawer โผล่บนมือถือ

  ngOnInit() {
    this.checkViewport(); // [ADDED]
  }

  // [ADDED] จับ resize เพื่อสลับโหมด desktop/mobile อัตโนมัติ
  @HostListener('window:resize')
  onResize() {
    this.checkViewport();
  }

  // [ADDED]
  private checkViewport() {
    const mobileNow = window.innerWidth < 1024;
    this.isMobileView = mobileNow;

    if (mobileNow) {
      // เข้าโหมดมือถือ/แท็บเล็ต:
      // sidebar เป็น drawer ซ่อนอยู่ก่อน
      this.mobileSidebarOpen = false;
    }
  }

  // [ADDED] sidebar ยิงสถานะ collapsed (แคบ/กว้าง) กลับมา
  // ใช้เฉพาะ desktop เพื่อบังคับ margin-left ของ main-content
  onSidebarToggle(collapsed: boolean) {
    if (!this.isMobileView) {
      this.isCollapsed = collapsed;
    }
  }

  // [ADDED] เรียกจาก hamburger ใน topbar
  toggleMobileSidebar() {
    if (this.isMobileView) {
      this.mobileSidebarOpen = !this.mobileSidebarOpen;
    }
  }

  // [ADDED] ปิด drawer เมื่อกด backdrop
  closeMobileSidebar() {
    if (this.isMobileView) {
      this.mobileSidebarOpen = false;
    }
  }
}
