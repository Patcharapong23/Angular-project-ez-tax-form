import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './features/auth/login/login.component';
import { RegisterComponent } from './features/auth/register/register.component';
import { DashboardComponent } from './features/dashboard/dashboard.component';
import { RegisterSuccessComponent } from './features/auth/register-success/register-success.component';
import { LayoutComponent } from './features/layout/layout.component';
import { DocumentsallComponent } from './features/documentsall/documentsall.component';
import { InvoiceFormComponent } from './features/invoice/invoice-form/invoice-form.component'; // << เพิ่ม
import { AuthGuard } from './auth.guard'; // << ใช้คลาส
import { ApiRewriteInterceptor } from './shared/api-rewrite.interceptor';
import { HTTP_INTERCEPTORS } from '@angular/common/http';

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'login' },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'register-success', component: RegisterSuccessComponent },

  {
    path: '',
    component: LayoutComponent,
    canActivate: [AuthGuard],
    children: [
      { path: 'dashboard', component: DashboardComponent },
      { path: 'documentsall', component: DocumentsallComponent },

      // ไม่ใช้ loadComponent (Router รุ่นนี้ยังไม่รองรับ)
      { path: 'invoice-form', component: InvoiceFormComponent },
      { path: 'invoice/edit/:docNo', component: InvoiceFormComponent },
      { path: 'invoice/view/:docNo', component: InvoiceFormComponent },

      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
    ],
  },

  { path: '**', redirectTo: 'login' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: ApiRewriteInterceptor,
      multi: true,
    },
  ],
})
export class AppRoutingModule {}
