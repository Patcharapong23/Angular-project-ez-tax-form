import { Injectable } from '@angular/core';
import { CanActivate, Router, UrlTree } from '@angular/router';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { AuthService } from './shared/auth.service';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
  constructor(private auth: AuthService, private router: Router) {}

  canActivate(): Observable<boolean | UrlTree> | boolean | UrlTree {
    // ไม่มี token เลย → ไป login
    if (!this.auth.token) {
      return this.router.createUrlTree(['/login']);
    }

    // มี token และยังไม่หมดอายุ
    if (this.auth.isLoggedIn()) {
      // ถ้ายังไม่มี user ใน memory ให้โหลด /auth/me ครั้งแรกหลังรีเฟรช
      if (!this.auth.getUser()) {
        return this.auth.fetchMe().pipe(
          map(() => true),
          catchError(() => of(this.router.createUrlTree(['/login'])))
        );
      }
      return true;
    }

    // token หมดอายุ → ไป login
    return this.router.createUrlTree(['/login']);
  }
}
