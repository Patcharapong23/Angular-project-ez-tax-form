import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

/* ===== Angular Material ===== */
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatOptionModule } from '@angular/material/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatTableModule } from '@angular/material/table';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSelectModule } from '@angular/material/select';
import { OverlayModule } from '@angular/cdk/overlay';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';

/* ===== Components ===== */
import { SidebarComponent } from './shared/sidebar/sidebar.component';
import { LayoutComponent } from './features/layout/layout.component';
import { TopbarComponent } from './shared/topbar/topbar.component';
import { LoginComponent } from './features/auth/login/login.component';
import { RegisterComponent } from './features/auth/register/register.component';
import { DashboardComponent } from './features/dashboard/dashboard.component';
import { RegisterSuccessComponent } from './features/auth/register-success/register-success.component';
import { DocumentsallComponent } from './features/documentsall/documentsall.component';
import { NewDocumentDialogComponent } from './features/dialogs/new-document-dialog/new-document-dialog.component';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { SaveSuccessDialogComponent } from './features/dialogs/save-success/save-success-dialog.component';
import { ExportDialogComponent } from './features/dialogs/export-dialog/export-dialog.component';

/* ===== Interceptorsimport { InvoiceModule } from './features/invoice/invoice.module';
 ===== */
import { LoadingInterceptor } from './shared/Loding/loading.interceptor';
import { JwtInterceptor } from './shared/jwt.interceptor';
import { InvoiceFormComponent } from './features/invoice/invoice-form/invoice-form.component';

/* ===== Guards ===== */
import { AuthGuard } from './auth.guard';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterSuccessComponent,
    RegisterComponent,
    DashboardComponent,
    SidebarComponent,
    TopbarComponent,
    LayoutComponent,
    DocumentsallComponent,
    InvoiceFormComponent,
    NewDocumentDialogComponent,
    SaveSuccessDialogComponent,
    ExportDialogComponent,
  ],
  imports: [
    BrowserModule,

    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule,
    OverlayModule,
    CommonModule,
    // Material
    MatDatepickerModule,
    MatNativeDateModule,
    MatProgressSpinnerModule,
    MatFormFieldModule,
    MatInputModule,
    MatAutocompleteModule,
    MatOptionModule,
    MatButtonModule,
    MatIconModule,
    MatTableModule,
    MatDialogModule,
    MatCheckboxModule,
    MatSelectModule,
    MatSnackBarModule,
  ],
  providers: [
    AuthGuard,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: JwtInterceptor,
      multi: true,
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: LoadingInterceptor,
      multi: true,
    },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
